# CommerceLab 포트폴리오 스타터

이 키트는 이력서와 공개 가능한 사진을 바탕으로 반응형 포트폴리오를 만드는 실전 시작점입니다.

1. `DESIGN-GUIDE.md`를 먼저 읽어 확정 글씨체와 시각 규칙을 이해합니다.
2. `PROFILE_TEMPLATE.md`에 공개 가능한 사실만 적습니다.
3. 사진과 캡처는 개인정보를 지운 뒤 `portfolio/assets`에 넣습니다.
4. AI에게 ZIP 전체와 `PROMPTS.md`의 마스터 요청문을 전달합니다.
5. AI가 `portfolio/index.html`과 `portfolio/assets/design-system.css`를 수정하게 합니다.
6. `CHECKLIST.md`로 PC·모바일·사실·공개 안전성을 검수합니다.

원본 이력서의 주민번호, 전화번호, 주소, 서명, 사내 수치와 비밀번호는 ZIP에 넣지 마세요.
