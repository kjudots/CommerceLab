# CommerceLab 업무 OS 전체 키트

이 키트는 포트폴리오를 포함해 실제 업무 노하우를 정의 → 계획 → 영입·육성 → 측정 → 학습의 운영 체계로 만드는 올인원 패키지입니다.

## 가장 쉬운 순서

1. `portfolio` 폴더의 `START-HERE.md`부터 진행해 본인의 경력과 성과를 정리합니다.
2. `DESIGN-SYSTEM.md`와 `assets/design-system.css`를 AI에게 먼저 읽힙니다.
3. `WORK-OS-INTERVIEW.md`에 반복해서 해결해 온 문제와 도구를 적습니다.
4. `OS_CONTENT_MAP.md`에서 만들 모듈을 고릅니다.
5. `PROMPTS.md`의 마스터 요청문으로 한 화면씩 제작합니다.
6. `demo/md-os-starter.html`을 브라우저로 열어 디자인과 모바일 동작을 확인합니다.
7. `CHECKLIST.md`를 모두 통과한 뒤 GitHub Pages에 공개합니다.

실제 회사 내부 자료를 복제하지 마세요. 구조와 판단 방식만 가져오고 브랜드·금액·고객·계약 조건은 공개 가능한 사실 또는 명확히 표시한 가상 데이터로 바꿉니다.
