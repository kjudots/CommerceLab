# 커머스 KPI 용어집

| 약어·용어 | 풀어쓴 뜻 | 실무 해석 |
|---|---|---|
| GMV | Gross Merchandise Value, 총거래액 | 취소·반품 기준을 함께 명시 |
| CTR | Click Through Rate, 클릭률 | 노출 대비 클릭 비율 |
| CVR | Conversion Rate, 전환율 | 세션 또는 클릭 대비 구매 비율 |
| CAC | Customer Acquisition Cost, 고객획득비용 | 신규 고객 1명 확보 비용 |
| AOV | Average Order Value, 평균주문금액 | 주문 1건당 평균 결제액 |
| P&L | Profit and Loss, 손익 | 매출에서 비용과 이익까지 보는 구조 |
| 공헌이익 | Contribution Margin | 매출에서 변동비를 뺀 이익 기여분 |
| 재고회전율 | Inventory Turnover | 일정 기간 재고가 판매·교체된 속도 |
| 재구매율 | Repeat Purchase Rate | 기존 구매자가 다시 구매한 비율 |
| 이탈·복귀 | Churn / Reactivation | 구매 중단과 재활성화 고객 흐름 |

지표를 쓸 때는 분모·기간·채널·취소 반영 기준을 함께 표시합니다.
