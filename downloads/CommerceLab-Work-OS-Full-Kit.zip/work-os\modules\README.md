# 업무 모듈 폴더

완성한 HTML을 아래 이름처럼 한 장씩 추가하세요.

- `01-role-definition.html`
- `02-waterfall-progress.html`
- `03-seller-acquisition.html`
- `04-partner-growth.html`
- `05-performance-dashboard.html`
- `06-retrospective.html`

각 모듈은 목적에 맞는 레이아웃을 사용하되 `../assets/design-system.css`의 글씨체와 토큰을 공유합니다.
